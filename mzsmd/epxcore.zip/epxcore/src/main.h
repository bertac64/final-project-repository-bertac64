/**
 * main.h - header del programma epcore.
 *
 * (C) 2008 GGH Srl per Igea SpA
 *
 */
#ifndef MAIN_H_
#define MAIN_H_
void comm_error(const char *msg);

#endif /*MAIN_H_*/
